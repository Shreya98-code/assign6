# -*- coding: utf-8 -*-
"""

Created on Sat Mar  07 10:03:24 2020

@Author: Shreya_agrawal 
"""

"""

Preprocessing library for Assignment 6 

"""

import re
import os
import zipfile as zf

from nl_stuff import TweetTokenizer


class Preprocessor:
    """
    Pre processing text to generate padded embeddings of tweet
    """
    def __init__(self, pad_length_tweet=50, dict_size=3000000):

        """
        Initializing class
        parameters pad_length_tweet, max_length_dictionary:


        Self parameters
        embeddings_dict, file_path
        """

        self.pad_length_tweet = pad_length_tweet
        self.dict_size = dict_size

        #accessing dictionary file inside zipped folder       
        file_path = './Preprocessor.zip/word_list.txt'
        archive_path = os.path.abspath(file_path)
        split = archive_path.split(".zip/")
        archive_path = split[0] + ".zip"
        path_inside = split[1]
        archive = zf.ZipFile(archive_path, "r")
        self.embeddings = archive.read(path_inside).decode("utf8").split("\n")

        #limiting the dictionary size to specified limit
        self.embeddings = self.embeddings[:dict_size]

        #creating tweet tokenizer object
        self.token_gen = TweetTokenizer()

        # import stopwords
        file_path = './Preprocessor.zip/english'
        archive_path = os.path.abspath(file_path)
        split = archive_path.split(".zip/")
        archive_path = split[0] + ".zip"
        path_inside = split[1]
        archive = zf.ZipFile(archive_path, "r")
        self.stopwords = archive.read(path_inside).decode("utf8").split("\n") 

    def step1_clean(self, tweet):
        """
        First step is to perform preliminary cleaning action on tweet
        """

        #reomving hyperlinks, numbers, hashtags
        tweet = tweet.lower()
        tweet = re.sub(r"(https?:\/\/)?([\da-z\.-]+)\.([a-z\.]{2,6})([\/\w \.-]*)", '', tweet)     
        tweet = re.sub(r"[0-9]+", '', tweet)
        tweet = re.sub(r"#", '', tweet)

        #clearing twitter handles
        tweet = re.sub(r"@[a-zA-Z0-9]+", '', tweet)

        # removing Stopwords
        clean_tweet_list = [word for word in tweet.split() if word not in self.stopwords]
        cleaned_tweet = " ".join(clean_tweet_list)

        return cleaned_tweet

    def step2_tokenize(self, tweet):

        """
        Next step is to create a word vector using tweet tokenizer
        """

        tokenized_tweet = self.token_gen.tokenize(tweet)

        return tokenized_tweet

    def step3_token_to_index(self, tweet_token):
        """
        Replacing token with embeddings index from dict
        """

        list_of_index = []
        for word in tweet_token:
            try:
                token_index = self.embeddings.index(word)
                list_of_index.append(token_index)
            except ValueError:
                token_index = self.embeddings.index('<unknown>')
                list_of_index.append(token_index)

        return list_of_index

    def step4_padding_list(self, index_list):
        """
        Padding the index list of tokens to reach the padding length decided earlier
        """

        length1 = len(index_list)
        #This padding is done based on size of the index list

        if length1 < self.pad_length_tweet:
            req_d = self.pad_length_tweet - length1
            index_list.extend([self.embeddings.index('<pad>')]*req_d)
            pad_list = index_list

        elif length1 == self.pad_length_tweet:
            pad_list = index_list

        else:
            pad_list = index_list[:self.pad_length_tweet]

        return pad_list

    def tweet_process(self, tweet):

        """
        end to end function performing all the steps 1-4
        """

        cleaned = self.step1_clean(tweet)
        #print cleaned
        tokenized = self.step2_tokenize(cleaned)
        #print tokenized
        token_index = self.step3_token_to_index(tokenized)
        #print token_index
        padded_index = self.step4_padding_list(token_index)
        #print padded_index

        return padded_index



#SAMPLE = "President has announced warning period"
#TWITTER = Preprocessor()
#TWITTER.tweet_process(SAMPLE)
